import {Directive,Inject} from './Angular';

@Directive('sidebar')
export class SidebarDirective {

    //public static controllerAs:string = 'terminalDirective';
    public static templateUrl:string = 'views/terminal.html';
    public static restrict:string = 'E';

    public static link:angular.IDirectiveLinkFn = (scope:ng.IScope, element:JQuery, attrs:any, ctrl:SidebarDirective) => {
        scope.$eval(attrs.terminal);
    };

    constructor(@Inject('$scope') private $$scope:angular.IScope,
                @Inject('$parse') private $$parse:angular.IParseService) {
        // do stuff with $$scope and $$parse;
        console.log('SidebarDirective SidebarDirective');
    }

    public init(anArg:string):any {
        console.log('terminalDirective');
        // do some stuff with this.$$parse and this.$$scope
        //return true;
    }

}
