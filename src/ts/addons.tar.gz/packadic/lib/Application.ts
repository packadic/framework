import * as helpers from './helpers';
import {IConfigProperty,IConfig,ConfigObject} from "./Config";
import * as extensions from "./Extensions";
import * as util from '../util/index';
import {PromiseInterface, DeferredInterface, create as createPromise} from "../util/promise";
import {Debug} from "./Debug";
import {EventEmitter2} from 'eventemitter2';
import _ = require('lodash');
import $ = require('jquery');
import _$ = require('bootstrap');_$;
import _$m = require('bootstrap-material-design');_$m;

/**
 * The application class
 */

var $body:JQuery = $('body');

export var app:Application;

var configDefaults:any = {
    baseUrl: location.origin,
    assetPath: '/assets',
    vendor: {
        material: {
            "input": true,
            "ripples": true,
            "checkbox": true,
            "togglebutton": true,
            "radio": true,
            "arrive": true,
            "autofill": false,
            "withRipples": [".btn:not(.btn-link)", ".card-image", ".navbar a:not(.withoutripple)", ".dropdown-menu a", ".nav-tabs a:not(.withoutripple)", ".withripple"].join(","),
            "inputElements": "input.form-control, textarea.form-control, select.form-control",
            "checkboxElements": ".checkbox > label > input[type=checkbox]",
            "togglebuttonElements": ".togglebutton > label > input[type=checkbox]",
            "radioElements": ".radio > label > input[type=radio]"
        },
        slimscroll: {
            allowPageScroll: false,
            size: '6px',
            color: '#37474f', //util.material.color('blue-grey', 800),
            wrapperClass: 'slimScrollDiv',
            railColor: '#607d8b', //util.material.color('blue-grey', 500),
            position: 'right',
            height: '200px',
            alwaysVisible: false,
            railVisible: true,
            disableFadeOut: true
        },
        bootstrap: {
            tooltip: {
                container: 'body',
                template: '<div class="tooltip tooltip-packadic" role="tooltip"><div class="tooltip-inner"></div></div>',
                selector: '*[data-toggle="tooltip"]'
            },
            popover: {
                selector: '*[data-toggle="popover"]'
            }
        }
    }
};

export function getConfigDefaults():any {
    return configDefaults;
}

export function mergeIntoDefaultConfig(obj:any = {}) {
    configDefaults = _.merge(configDefaults, obj)
}


/****************************/
// Application ready callbacks
/****************************/

var isReady:boolean = false;

/**
 * @private
 */
export var _readyCallbacks:Function[] = [];

export function ready(fn:Function) {
    if (isReady) {
        fn.apply(fn, [Application.instance]);
    } else {
        _readyCallbacks.push(fn);
    }
}


/**
 * @private
 */
export function callReadyCallbacks(app:Application) {
    if (isReady) {
        return;
    }
    _readyCallbacks.forEach((fn:Function) => {
        fn.apply(fn, [app])
    });
    isReady = true;
}


export interface IApplication {

}

export function EventHook(hook:string) {
    return (cls:any, name:string, desc:PropertyDescriptor):PropertyDescriptor => {
        console.log('EventHook(' + hook + ')', cls, name, desc);
        desc.value = void 0;
        return desc;
    }
}

/**
 * The Application class is the main class initialising and booting all other components, plugins, etc
 *
 * ```typescript
 * var app:packadic.Application = packadic.Application.instance
 * app.DEBUG = true;
 * app.init({
     *      customConfigVariable: 'asdf'
     * });
 * app.boot().then(function(app:packadic.Application){
     *     // Application booted
     *     $('someElement').superDuperPlugin({
     *
     *     });
     * });
 * ```
 */
export class Application implements IApplication {

    /****************************/
    // Vue data
    /****************************/

    public data:any = {};

    /**
     * Default configuration values, these will be set after initial construction using getConfigDefaults()
     */
    public static defaults:any;

    protected static _instance:Application;


    /**
     * If true, the debug log will be enabled, with some other additions as well
     */
    public static DEBUG:boolean = false;

    /**
     * @private
     */
    protected _events:EventEmitter2;
    protected _debug:Debug;

    /**
     * The configuration repository
     */
    public config:IConfigProperty;

    /**
     * @private
     */
    protected _config:IConfig;

    public isInitialised:boolean;
    public isBooted:boolean;

    public timers:any = {construct: null, init: null, boot: null};

    public get extensions():extensions.Extensions {
        return extensions.Extensions.instance;
    }

    constructor(options?:{}) {
        //super(options);
        this._events = new EventEmitter2({
            wildcard: true,
            delimiter: ':',
            maxListeners: 1000,
            newListener: true
        });
        $body.data('packadic', this);
        var self:Application = this;


        Application.defaults = getConfigDefaults();

        this.timers.construct = new Date;
        this.isInitialised = false;
        this.isBooted = false;
        this._debug = new Debug();

    }

    /**
     * @returns {Application}
     */
    public static get instance() {
        if (typeof Application._instance === "undefined") {
            Application._instance = new Application();
            app = Application._instance;
        }
        return Application._instance;
    }

    public init(opts:any = {}):Application {
        if (this.isInitialised) {
            return;
        } else {
            this.isInitialised = true;
        }
        this.emit('pre-init');

        this.timers.init = new Date;
        //Vue.config.debug = this.DEBUG;
        if (Application.DEBUG) {
            window['app'] = this;
            this.debug.enable();
            this.debug.setStartDate(this.timers.construct);
            console.groupCollapsed('DEBUG: init');
        }

        this._config = new ConfigObject($.extend({}, Application.defaults, opts));
        this.config = ConfigObject.makeProperty(this._config);

        // get the stylesheet data from the head. also parse all int stuff
        var styles:any = JSON.parse(util.str.unquote($('head').css('font-family'), "'"));
        ['breakpoints', 'containers'].forEach((name:string) => {
            $.each(styles['style'][name], (key:string, val:string) => {
                styles['style'][name][key] = parseInt(val);
            });
        });
        this.config.merge(styles);


        this.extensions.loadAll();

        this.extensions.each((comp:extensions.Extension) => {
            this[comp.name] = comp;
        });

        helpers.registerHelperPlugins();

        callReadyCallbacks(this);

        this.emit('init', this);
        if (Application.DEBUG) console.groupEnd();
        return this;
    }

    public boot():PromiseInterface<Application> {
        var defer:DeferredInterface<Application> = createPromise();
        if (!this.isInitialised) {
            throw new Error('Calling boot before init is not acceptable');
        }
        if (this.isBooted) {
            setTimeout(() => {
                defer.resolve(this);
            }, 100);
            return defer.promise;
        }
        if (Application.DEBUG) console.groupCollapsed('DEBUG: boot');

        $(() => {
            this.emit('boot', this);

            this.timers.boot = new Date;
            if (!util.isTouchDevice()) {
                $body.tooltip(this.config('vendor.bootstrap.tooltip'));
            }
            $body.popover(this.config('vendor.bootstrap.popover'));
            $.material.options = this.config('vendor.material');
            $.material.init();
            this.isBooted = true;
            this.emit('booted', this);
            if (Application.DEBUG) console.groupEnd();
            defer.resolve(this);
        });
        return defer.promise;
    }


    public get debug():Debug {
        return this._debug;
    }

    public getAssetPath(path:string = '', prefixBaseUrl:boolean = true):string {
        path = util.str.startsWith(path, '/') ? path : '/' + path;
        return (prefixBaseUrl ? this.config('baseUrl') : '') + this.config('assetPath') + path;
    }


    /****************************/
    // Script/css module loader
    /****************************/
    protected _loaded:{[name:string]:boolean} = {};

    public load(type:string, path:string, bower:boolean = false, pathSuffix:string = ''):PromiseInterface<any[]> {
        var defer:DeferredInterface<any> = createPromise();
        path = util.str.endsWith(path, '.' + type) ? path : path + '.' + type;
        var fullPath = this.getAssetPath((bower ? 'bower_components/' : 'scripts/') + path) + pathSuffix;
        this._loaded[fullPath] = true;
        //debug.log('loading', path);
        System.import(fullPath).then(function (...args:any[]) {
            //debug.log('loaded', path, args);
            defer.resolve(args)
        });
        return defer.promise;
    }

    public loadJS(path:string, bower:boolean = false):PromiseInterface<any[]> {
        return this.load('js', path, bower);
    }

    public loadCSS(path:string, bower:boolean = false):PromiseInterface<any[]> {
        return this.load('css', path, bower, '!css');
    }


    /****************************/
    // Events
    /****************************/

    public on(event:string, listener:Function):Application {
        if (event === 'init' && this.isInitialised && listener(this)) {
            return;
        }

        this._events.on(event, listener);
        return this;
    }

    public once(event:string, listener:Function):Application {
        this._events.once(event, listener);
        return this;
    }

    public off(event:string, listener:Function):Application {
        this._events.off(event, listener);
        return this;
    }

    public emit(event:string, ...args:any[]):Application {
        if (Application.DEBUG) {
            this.debug.logEvent(event, args);
        }
        this._events.emit(event, args);
        return this;
    }


    public booted(fn:Function) {
        if (this.isBooted) {
            fn([this]);
        } else {
            this.once('booted', fn);
        }
    }
}


