/// <reference path="../types.d.ts" />
import * as angular from 'angular';
import {Application} from "./lib/Application";
import {Debug} from "lib/Debug";

angular.module('packadic', []);
Application.DEBUG = true;
export var app:Application = Application.instance;
app.init();
app.boot().then(() => {
    app.debug.log('Done');
});


/****************************/
// Config Defaults
/****************************/
