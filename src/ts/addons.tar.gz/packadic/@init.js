/// <reference path="../types.d.ts" />
var angular = require('angular');
console.groupCollapsed('Packadic pre-init logs');
var packadic;
(function (packadic) {
    angular.module('packadic', []);
    var configDefaults = {
        baseUrl: location.origin,
        assetPath: '/assets',
        vendor: {
            material: {
                "input": true,
                "ripples": true,
                "checkbox": true,
                "togglebutton": true,
                "radio": true,
                "arrive": true,
                "autofill": false,
                "withRipples": [".btn:not(.btn-link)", ".card-image", ".navbar a:not(.withoutripple)", ".dropdown-menu a", ".nav-tabs a:not(.withoutripple)", ".withripple"].join(","),
                "inputElements": "input.form-control, textarea.form-control, select.form-control",
                "checkboxElements": ".checkbox > label > input[type=checkbox]",
                "togglebuttonElements": ".togglebutton > label > input[type=checkbox]",
                "radioElements": ".radio > label > input[type=radio]"
            },
            slimscroll: {
                allowPageScroll: false,
                size: '6px',
                color: '#37474f',
                wrapperClass: 'slimScrollDiv',
                railColor: '#607d8b',
                position: 'right',
                height: '200px',
                alwaysVisible: false,
                railVisible: true,
                disableFadeOut: true
            },
            bootstrap: {
                tooltip: {
                    container: 'body',
                    template: '<div class="tooltip tooltip-packadic" role="tooltip"><div class="tooltip-inner"></div></div>',
                    selector: '*[data-toggle="tooltip"]'
                },
                popover: {
                    selector: '*[data-toggle="popover"]'
                }
            }
        }
    };
    function getConfigDefaults() {
        return configDefaults;
    }
    packadic.getConfigDefaults = getConfigDefaults;
    function mergeIntoDefaultConfig(obj) {
        if (obj === void 0) { obj = {}; }
        configDefaults = _.merge(configDefaults, obj);
    }
    packadic.mergeIntoDefaultConfig = mergeIntoDefaultConfig;
    var isReady = false;
    packadic._readyCallbacks = [];
    function ready(fn) {
        if (isReady) {
            fn.apply(fn, [packadic.app]);
        }
        else {
            packadic._readyCallbacks.push(fn);
        }
    }
    packadic.ready = ready;
    function callReadyCallbacks(app) {
        if (isReady) {
            return;
        }
        packadic._readyCallbacks.forEach(function (fn) {
            fn.apply(fn, [app]);
        });
        isReady = true;
    }
    packadic.callReadyCallbacks = callReadyCallbacks;
})(packadic || (packadic = {}));
//# sourceMappingURL=@init.js.map
