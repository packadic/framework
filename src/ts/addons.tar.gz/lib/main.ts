import * as angular from 'angular';
import $ from 'jquery';

console.log('main ts', angular);
