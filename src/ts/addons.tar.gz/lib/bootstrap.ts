console.log('bootstrap ts');

export function bootstrap(){
    console.log('bootstrap ts bootstrap()');
}
