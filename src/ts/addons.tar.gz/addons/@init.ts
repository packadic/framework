/// <reference path="./../types.d.ts" />
/// <reference path="./../packadic.d.ts" />

module packadic {


}
